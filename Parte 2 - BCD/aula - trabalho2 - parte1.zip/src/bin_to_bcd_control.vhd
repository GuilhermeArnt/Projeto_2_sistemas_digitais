library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity bin_to_bcd_control is
  generic (
    N_BITS   : positive := 8; -- Número de bits do número binário de entrada.
    N_DIGITS : positive := 3 -- Número de dígitos BCD
  );
  port (
    start          : in std_logic; -- Sinal para iniciar a conversão.
    ready          : out std_logic; -- Indica que a FSM está pronta para um novo início.
    ctrl_init      : out std_logic; -- Inicializa os registradores.
    ctrl_check_add : out std_logic; -- Executar a verificação e soma de +3.
    ctrl_shift     : out std_logic; -- Efetua o deslocamento (shift).
    done_counting  : in std_logic; -- Indica que o número de iterações do algorítimo terminou.
    done           : out std_logic; -- Pulso que indica a conclusão da conversão.
    clk            : in std_logic; -- Sinal de relógio (clock).
    rst            : in std_logic -- Sinal de reset assíncrono.
  );
end entity;

architecture behavior of bin_to_bcd_control is
  type state_type is (ST_IDLE, ST_INIT, ST_CHECK_ADD, ST_SHIFT, ST_DONE);

begin


end architecture behavior;
